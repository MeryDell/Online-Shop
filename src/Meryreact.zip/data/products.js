export const products = [
  {
    id: 1,
    title: "Midnight Satin Dress",
    price: 89,
    image: "https://i.pinimg.com/1200x/67/2f/e0/672fe0bce302280235d388f81d8c4e52.jpg",
  },
  {
    id: 2,
    title: "Noir Evening Dress",
    price: 95,
    image: "https://i.pinimg.com/1200x/69/e7/7e/69e77e1811db766ecdc7b2da439a280b.jpg",
  },
  {
    id: 3,
    title: "Satin Muse Blouse",
    price: 59,
    image: "https://i.pinimg.com/1200x/69/a5/68/69a5684c1fcdf4a2cfb5a8eaebb370c7.jpg",
  },
  {
    id: 4,
    title: "Burgundy Elegance Top",
    price: 49,
    image: "https://i.pinimg.com/736x/f0/ce/ed/f0ceed45b2880925a6c54b073a9e08fd.jpg",
  },
  {
    id: 5,
    title: "The Obscur Mini Dress",
    price: 69,
    image: "https://i.pinimg.com/736x/de/4c/31/de4c319bc6cadbad8f6efcc0617612fb.jpg",
  },
  {
    id: 6,
    title: "Classic Noir Blouse",
    price: 55,
    image: "https://i.pinimg.com/1200x/d3/03/00/d303008619bd0b60d9b3e8056599fee0.jpg",
  },
  {
    id: 7,
    title: "Everyday Essential Top",
    price: 35,
    image: "https://i.pinimg.com/736x/66/e1/c1/66e1c1a2ce66a12b98ca60c642ebc392.jpg",
  },
  {
    id: 8,
    title: "Evening Silhouette Dress",
    price: 99,
    image: "https://i.pinimg.com/736x/34/3b/24/343b2438ab8a0ec012c0a60b351f1006.jpg",
  },
];
